﻿using System.Net.Sockets;
using System.Text;

class Program
{
    static Socket clientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
    const int BUFFER_SIZE = 2048;
    static byte[] buffer = new byte[BUFFER_SIZE];

    static void Main()
    {
        Console.WriteLine("Connecting to server...");
        clientSocket.Connect("127.0.0.1", 5000);
        Console.WriteLine("Connected");

        Thread receiveThread = new Thread(ReceiveLoop);
        receiveThread.Start();

        while (true)
        {
            string text = Console.ReadLine();
            byte[] data = Encoding.ASCII.GetBytes(text);
            clientSocket.Send(data);
        }
    }

    static void ReceiveLoop()
    {
        while (true)
        {
            int received = clientSocket.Receive(buffer);
            byte[] data = new byte[received];
            Array.Copy(buffer, data, received);
            Console.WriteLine("Server: " + Encoding.ASCII.GetString(data));
        }
    }
}
