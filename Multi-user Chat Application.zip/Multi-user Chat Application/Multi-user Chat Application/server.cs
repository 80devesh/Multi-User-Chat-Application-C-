﻿using System.Net.Sockets;
using System.Net;
using System.Text;


class Program
{
    static List<Socket> clientSockets = new List<Socket>();
    static Socket serverSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
    const int BUFFER_SIZE = 2048;
    static byte[] buffer = new byte[BUFFER_SIZE];

    static void Main()
    {
        Console.WriteLine("Setting up server...");
        serverSocket.Bind(new IPEndPoint(IPAddress.Any, 5000));
        serverSocket.Listen(10);
        serverSocket.BeginAccept(AcceptCallback, null);
        Console.WriteLine("Server setup complete");
        while (true)
        {
            Console.ReadLine();
        }
    }

    private static void AcceptCallback(IAsyncResult AR)
    {
        Socket socket;
        try
        {
            socket = serverSocket.EndAccept(AR);
        }
        catch (Exception)
        {
            return;
        }

        clientSockets.Add(socket);
        socket.BeginReceive(buffer, 0, BUFFER_SIZE, SocketFlags.None, ReceiveCallback, socket);
        serverSocket.BeginAccept(AcceptCallback, null);
        Console.WriteLine("Client connected, waiting for request...");
    }

    private static void ReceiveCallback(IAsyncResult AR)
    {
        Socket current = (Socket)AR.AsyncState;
        int received;
        try
        {
            received = current.EndReceive(AR);
        }
        catch (Exception)
        {
            Console.WriteLine("Client forcefully disconnected");
            current.Close();
            clientSockets.Remove(current);
            return;
        }

        byte[] recBuf = new byte[received];
        Array.Copy(buffer, recBuf, received);
        string text = Encoding.ASCII.GetString(recBuf);
        Console.WriteLine("Received Text: " + text);

        foreach (Socket socket in clientSockets)
        {
            if (socket != current)
            {
                socket.Send(recBuf);
            }
        }

        current.BeginReceive(buffer, 0, BUFFER_SIZE, SocketFlags.None, ReceiveCallback, current);
    }
}
